const { test, expect } = require('@playwright/test');
const headers = process.env.REQRES_API_KEY ? {'x-api-key': process.env.REQRES_API_KEY} : {};

test('API-001 GET user', async ({request}) => { const r=await request.get('https://reqres.in/api/users/2',{headers}); expect(r.status()).toBe(200); const b=await r.json(); expect(b).toHaveProperty('data'); expect(b.data).toHaveProperty('id',2); expect(b.data).toHaveProperty('email'); });
test('API-002 POST create user', async ({request}) => { const r=await request.post('https://reqres.in/api/users',{headers,data:{name:'QA Tester',job:'Automation Engineer'}}); expect(r.status()).toBe(201); const b=await r.json(); expect(b).toHaveProperty('name','QA Tester'); expect(b).toHaveProperty('job','Automation Engineer'); expect(b).toHaveProperty('id'); expect(b).toHaveProperty('createdAt'); });
test('API-003 login missing password', async ({request}) => { const r=await request.post('https://reqres.in/api/login',{headers,data:{email:'peter@klaven'}}); expect(r.status()).toBe(400); const b=await r.json(); expect(b).toHaveProperty('error'); });
test('API-004 user not found', async ({request}) => { const r=await request.get('https://reqres.in/api/users/23',{headers}); expect(r.status()).toBe(404); const b=await r.json(); expect(typeof b).toBe('object'); });
