# SauceDemo QA Assignment

QA assignment covering manual testing, exploratory bug discovery, Playwright UI automation, ReqRes API testing, and GitHub Actions CI.

## Coverage
- 30 manual test cases (`docs/test-cases.xlsx`)
- Test plan (`docs/test-plan.md`)
- Bug-report verification templates (`docs/bug-reports.md`)
- 9 Playwright UI tests
- 4 ReqRes API tests
- GitHub Actions workflow

## Setup
```bash
npm install
npx playwright install chromium
npm test
```

Run separately:
```bash
npm run test:ui
npm run test:api
```

## ReqRes note
ReqRes behavior/auth requirements can change. Current documentation supports demo endpoints, while project-backed API usage uses an `x-api-key`. The API tests automatically send `REQRES_API_KEY` when it is provided.

macOS/Linux:
```bash
export REQRES_API_KEY="your_key"
npm run test:api
```

PowerShell:
```powershell
$env:REQRES_API_KEY="your_key"
npm run test:api
```

For CI, add `REQRES_API_KEY` as a GitHub Actions repository secret if your ReqRes calls require it.

## Manual evidence still required
The repository intentionally does **not** fabricate bug evidence. Reproduce at least three bugs yourself, take your own screenshots, put them in `screenshots/`, create one GitHub Issue per bug, and add those Issues to a Project board with To Do / In Progress / Done columns.

## Submission checklist
- Public GitHub repository
- 25+ manual cases
- 3+ genuinely reproduced bugs with screenshots
- One GitHub Issue per bug
- GitHub Project board
- 8+ UI automated tests
- GET/POST/negative/404 API coverage with body assertions
- README and passing CI where possible
