# Bug Report Templates / Verification Log

> IMPORTANT: Do not claim these as real bugs until you reproduce them yourself. The assignment requires screenshots and GitHub Issues. Put your own evidence in `screenshots/` and replace `VERIFY` with the observed result.

## BUG-001 — problem_user: Product images/content integrity issue (VERIFY)
**Severity:** Medium  
**Priority:** High  
**Steps:** Login as `problem_user` → inspect each inventory card → compare product name/image/detail behavior with `standard_user`.  
**Expected:** Each product card has the correct corresponding image and details.  
**Actual:** VERIFY AND WRITE OBSERVED BEHAVIOR.  
**Screenshot:** `screenshots/BUG-001.png`

## BUG-002 — problem_user: Cart or checkout interaction issue (VERIFY)
**Severity:** High/Medium after verification  
**Priority:** High  
**Steps:** Login as `problem_user` → add multiple products → open cart → proceed through checkout → exercise all fields/buttons.  
**Expected:** Buttons and form fields behave consistently and checkout can proceed with valid data.  
**Actual:** VERIFY AND WRITE OBSERVED BEHAVIOR.  
**Screenshot:** `screenshots/BUG-002.png`

## BUG-003 — performance_glitch_user: Excessive navigation/login delay (VERIFY)
**Severity:** Medium  
**Priority:** Medium  
**Steps:** Time repeated login/navigation attempts with `performance_glitch_user`, and compare with `standard_user` on the same machine/network.  
**Expected:** Normal navigation completes without an abnormal seeded delay.  
**Actual:** RECORD YOUR MEASURED TIMES AND OBSERVED DELAY.  
**Screenshot:** `screenshots/BUG-003.png`

## GitHub Issue checklist
Create one Issue per verified bug. Include Title, Severity, Priority, Environment, Preconditions, numbered Steps to Reproduce, Expected, Actual, and inline screenshot. Add all issues to a GitHub Project board with **To Do / In Progress / Done**.
