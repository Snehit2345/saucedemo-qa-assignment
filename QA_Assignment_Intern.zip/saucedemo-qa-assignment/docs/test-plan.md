# SauceDemo Test Plan

## Objective
Validate core e-commerce behavior on SauceDemo: authentication, inventory/product listing, sorting, cart, checkout, validation, and seeded-user behavior.

## Scope
**In scope:** login/logout, inventory display, product details, sorting, add/remove cart, cart badge/persistence, checkout form validation, checkout completion, navigation/edge cases, seeded users.  
**Out of scope:** real payments, database validation, load/security testing, backend internals.

## Accounts
`standard_user`, `locked_out_user`, `problem_user`, `performance_glitch_user`; password: `secret_sauce`.

## Test Types
Functional, UI, negative, edge/boundary, exploratory, regression, basic performance observation.

## Environment
Latest Chrome/Chromium on tester OS; public SauceDemo environment.

## Entry / Exit Criteria
Entry: site reachable and credentials available. Exit: planned cases executed; at least 3 reproducible seeded defects documented as GitHub Issues with evidence; automated suite and API suite runnable from README.

## Risks
Public demo behavior can change. Bug evidence must be captured during actual execution. Performance observations depend on network/device, so compare repeated runs and record timings.
